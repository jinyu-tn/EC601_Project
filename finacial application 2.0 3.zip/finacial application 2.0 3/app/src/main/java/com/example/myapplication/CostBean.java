package com.example.myapplication;


import java.io.Serializable;

public class CostBean implements Serializable {

    public String costDate;
    public String costMoney;
    public String costCategory;
    public String costTitle;
}
